sudo nvidia-smi -i 0 -pl 180
sudo nvidia-smi -i 1 -pl 180
sudo nvidia-smi -i 2 -pl 180
sudo nvidia-smi -i 3 -pl 180
sudo nvidia-smi -i 4 -pl 180
sudo nvidia-smi -i 5 -pl 180
sudo nvidia-smi -i 6 -pl 180
sudo nvidia-smi -i 7 -pl 180

./prover
