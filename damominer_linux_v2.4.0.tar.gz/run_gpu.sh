#!/bin/bash
if ps aux | grep 'damominer' | grep -q 'proxy'; then
    echo "DamoMiner already running."
    exit 1
else
    nohup ./damominer --address aleo1v2c96aa7eaxn8auah3h7x04xh7pmtf3sjxv2fn2akpyhpj2vcypq9ye9fw --proxy asiahk.damominer.hk:9090 >> aleo.log 2>&1 &

fi

